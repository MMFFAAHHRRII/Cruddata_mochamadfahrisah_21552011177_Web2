@include('posts.header')

<div class="row justify-content-center">
    <div class="col-md-12">
        @yield('content')
    </div>
</div>

@include('posts.footer')
