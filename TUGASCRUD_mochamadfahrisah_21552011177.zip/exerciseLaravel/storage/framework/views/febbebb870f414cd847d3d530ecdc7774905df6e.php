

<?php $__env->startSection('title', 'View Post'); ?>

<?php $__env->startSection('header-title', 'View Post'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card border-0 shadow-sm rounded">
        <div class="card-body">
            <h5 class="card-title">Judul Post</h5>
            <img src="<?php echo e(asset('images/254721151_utb_kotak.png')); ?>" class="img-fluid rounded mb-3" alt="Post Image" style="max-width: 100%;">
            <p class="card-text">Konten Post</p>
            <a href="#" class="btn btn-primary">Kembali</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\exerciseLaravel\resources\views/posts/view.blade.php ENDPATH**/ ?>