<!DOCTYPE html>
<html>
<head> 
    <title>Welcome</title>
</head>
<body> 
    <h1>Welcome to My Blog</h1>
    <p>This is the welcome page of my caravel application.</p>
    <a href="<?php echo e(route('posts.index')); ?>">
        <button>View All Posts</button>
    </a>
</body>
</html><?php /**PATH C:\Users\ASUS\Documents\exerciseLaravel\resources\views/welcome.blade.php ENDPATH**/ ?>