

<?php $__env->startSection('title', 'Data Posts'); ?>

<?php $__env->startSection('header-title', 'Data Posts'); ?>

<?php $__env->startSection('content'); ?>
<style>
    .pagination svg {
        width: 1em;
        height: 1em;
    }
</style>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td class="text-center">
                <?php if($post->image): ?>
                <img src="<?php echo e(asset('storage/' . $post->image)); ?>" class="rounded" style="width: 150px" alt="post  image">
                <?php else: ?>
                <span>no image</span>
                <?php endif; ?>
            </td>
            <td><?php echo e($post->title); ?></td>
            <td><?php echo e($post->content); ?></td>
            <td class="text-center">
                <form onsumbit="return confirm('apakah anda yakin ?');" action="<?php echo e(route('posts.destroy', $post->id)); ?>" method="POST">
                    <a href="<?php echo e(route('posts.view',  $post->id)); ?>" class="btn btn-dark btn-sm">SHOW</a>
                    <a href="<?php echo e(route('posts.edit',  $post->id)); ?>" class="btn btn-primary btn-sm">EDIT</a>
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger btn-sm">HAPUS</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="4" class="text-center">
                <div class="alert alert-danger">
                    Data Post Belum Tersedia
                </div>
            </td>
        </tr>
        <?php endif; ?>
    </tbody>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\exerciseLaravel\resources\views/posts/index.blade.php ENDPATH**/ ?>