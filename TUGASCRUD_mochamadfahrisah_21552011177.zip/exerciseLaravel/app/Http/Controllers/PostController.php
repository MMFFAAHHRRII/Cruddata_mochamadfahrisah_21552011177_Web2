<?php

namespace App\Http\Controllers;

use App\Models\Post;
use Illuminate\View\View;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PostController extends Controller
{
    /**
     * Summary of index
     * @return View
     */
    public function index(): View
    {
        // get posts
        $posts = Post::latest()->paginate(5);

        //kirim data post ke view
        return view('posts.index', compact('posts'));
    }

   
    public function add() {
        return view('posts.add');
    }

    public function View()
    {
        return view('posts.view');
    }

    public function edit()
    {
        return view('posts.edit');
    }

    public function login()
    {
        return view('posts.login');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'content' => 'required|string',
            'image' => 'required|file|mimes:jpeg,png,jpg,gif,svg,ico|max:2048'
        ]);

        $post = new Post();
        $post->title = $validated['title'];
        $post->content = $validated['content'];

        if ($request->hasFile('image')) {
            $imagePath = $request->file('image')->store('images', 'public');
            $post->image = $imagePath;
        }

        $post->save();

        return redirect()->route('posts.index')->with('success', 'Post created successfully');
    }
}